/*
 * Copyright (c) 2016 ARM Limited, All Rights Reserved
 */

#ifndef ARM_HAL_INTERRUPT_PRIVATE_H_
#define ARM_HAL_INTERRUPT_PRIVATE_H_

void platform_critical_init(void);

#endif
